module Snap.Snaplet.MongoDB.Functions
( module Snap.Snaplet.MongoDB.Functions.S
) where

import Snap.Snaplet.MongoDB.Functions.S